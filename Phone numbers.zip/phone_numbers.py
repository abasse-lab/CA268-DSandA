import sys

print("Enter a name and number, or a name and ? to query (!! to exit)")
d = {}
for x in sys.stdin:
    x = x.split()
    if x[0] == "!!":
        print("Bye")
        break
    elif len(x[1]) >= 4:
        d[x[0]] = x[1]
    elif len(x[1]) == 1:
        if x[0] in d:
            print("{} has number {}".format(x[0], d[x[0]]))
        else:
            print("Sorry, there is no {}".format(x[0]))