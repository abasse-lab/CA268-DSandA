def sol():
    return 'AFCBDE'