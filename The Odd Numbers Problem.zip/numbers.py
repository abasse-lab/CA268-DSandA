import sys

def get_odd_list():
    a = []
    num = int(input())
    while num != -1:
        if num % 2 == 1:
            a.append(num)
        num = int(input())
    return a

def main():
    # call the get_odd_list function and print the result
    odds = get_odd_list()
    print(odds)

if __name__ == "__main__":
    main()

