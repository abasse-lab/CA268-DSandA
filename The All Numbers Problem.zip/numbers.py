import sys

def get_evenodd_list():
    a = []
    b = []
    num = int(input())
    while num != -1:
        if num % 2 == 1:
            a.append(num)
        elif num % 2 == 0:
            b.append(num)
        num = int(input())
    return a, b

def main():
    # call the get_odd_list function and print the result
    odds, evens = get_evenodd_list()
    print(odds)
    print(evens)

if __name__ == "__main__":
    main()




