#
#   Return an empty list to get your list of numbers.
#
#   Then return a list of 10 lists representing the buckets
#
def sol():
    return [191,31,33,293,34,204,67,98,68,28,179]


#[191, 34, 33, 293, 31, 67, 204, 98, 68, 179, 28]
#[]