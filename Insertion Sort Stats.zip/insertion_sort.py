def insertion_sort(lst):
    count = 0
    tom = 0
    john = 0
    # At each pass ensure that that section is sorted.
    for todo in range(1, len(lst)):
        # Find correct position for lst[todo].
        i = todo
        count += 1
        while i > 0 and lst[i] < lst[i-1]:
            lst[i], lst[i-1] = lst[i-1], lst[i] # Swap it down towards the correct position
            i -= 1
            tom += 1
            if i == 0:
              john += 1
    return "({}, {})".format((count + tom) - john, tom)
