#
#   Return an empty list to get your list of numbers.
#
#   Then return a list of lists corresponding to the passes of an insertion sort on the numbers.
#
def solution():
    return [
        [6, 7],
        [6, 7, 9],
        [6, 7, 9, 12],
        [4, 6, 7, 9, 12],
        [4, 6, 7, 9, 12, 16],
    ]