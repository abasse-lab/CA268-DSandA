import sys
c = []
for x in sys.argv[1:]:
  f = open(x, "r")
  d = f.readlines()
  for x in d:
    c.append(x.strip())

y = 1
c = sorted(c)
for i in c:
  if c.count(i) > 1:
    print ("{}. {}".format(y, i))
    c = [e for e in c if e != i]
    y += 1
