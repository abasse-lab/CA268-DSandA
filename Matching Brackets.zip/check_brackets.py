def check_brackets(line):
    y = 0
    a, b = '(', ')'

    for i in line:
        if i is a:
            y += 1
        elif i is b:
            y -= 1
        if y < 0:
            return False
    return y is 0
