import sys
def make_map():
   a = input()
   d = {}
   while a != '' :
       y = a.strip().split(' ')
       d[y[0]]=y[1]
       a = input()
   return d

def main(argv):
    student = make_map() # Call the student function
    print(type(student)) # check the type ... should be a map (or in python, dict)
    names = student.keys()   # get all names
    for name in sorted(names): # sort the names
        print(name + " has mark " + student[name]) # print the names and marks
    
if __name__ == "__main__":
    main(sys.argv[1:])