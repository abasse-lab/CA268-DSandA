def sol():
    return [0,34,31,23,21,12]
