def even_count(lst):
  temp = lst.head
  count = 0
  while (temp is not None):
    if temp.item % 2 == 0:
      count += 1
    temp = temp.next
  return count