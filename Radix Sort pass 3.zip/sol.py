#
#   Return an empty list to get your list of binary numbers.
#
#   Then return a list of strings representing the binary numbers in the correct positions
#
def sol():
    return ['0000','1011','0011','0100','0101','1110']


#0000,0100,1110,1011,0011,0101
#0000,0100,0101,1110,1011,0011
#0000,1011,0011,0100,0101,1110