#
#  Just a class to store the item and the next pointer
#
class Node:
    def __init__(self, item, next):
        self.item = item
        self.next = next

#
#   LinkedList class
#
class LinkedList:
    def __init__(self):
        self.head = None

    def add(self, item):
        self.head = Node(item, self.head)

    def remove(self):
        if self.is_empty():
            return None
        else:
            item = self.head.item
            self.head = self.head.next    # remove the item by moving the head pointer
            return item

    def is_empty(self):
        return self.head == None
        
    def duplicates(self):
        return self.count_even_rec(self.head)

    def count_even_rec(self, node):
        if (node is None or node.next is None):
            return False

        if node.item != node.next.item:
            return self.count_even_rec(node.next)
        else:
            return True
	 	  	   	 	      	    	        	 	
