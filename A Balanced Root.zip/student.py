def r_height(self, abc):
    if abc is None:
        return 0
    return (self.r_height(abc.left) - self.r_height(abc.right))

def is_avl(bst):
    if bst == None:
        return True
    if abs(bst.r_height(bst.root.right) - bst.r_height(bst.root.left)) > 1:
        return False
    return True
