def sol():
    return 87