import sys
print("Enter numbers (-1 to end):", end="")
f = sys.stdin.read().split()
string = ""
c = []
for x in f:
  if x in c:
    string += "{} ".format(x)
  c.append(x)
print (" {}".format(string))
