def rotation_type(bst):
    root = bst.root
    st = ""
    return inorder(root, st)
    

def inorder(root, st):
    while root != None:
        if root.right == None and root.left == None:
            return st
        if root.right == None:
            st += "l"
            root = root.left
        elif root.left == None:
            st += "r"
            root = root.right
    return st