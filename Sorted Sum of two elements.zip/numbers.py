def sum_to_k(lst, k):
  x = 0
  y = len(lst) - 1
  while x < y:
    if x == y:
      return False
    elif lst[x] + lst[y] < k:
      x += 1
    elif lst[x] + lst[y] == k:
      return True
    elif lst[x] + lst[y] > k:
      y -= 1
  return False