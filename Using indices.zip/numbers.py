import sys

def get_counts(words=[]):
    counts = [0] * 10
    for x in words:
        y = len(x)
        counts[y] += 1
    return counts

def main():
    # read the list of words from stdin
    line = sys.stdin.readline()
    line = line.strip()
    words = line.split()

    # call the student's function and ...
    counts = get_counts(words)
    # ... print the result
    for length in range(10):
        print(str(length) + ": " + str(counts[length]))

if __name__ == "__main__":
    main()
