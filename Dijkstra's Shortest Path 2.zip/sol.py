def sol():
    return 'AFEDCB'