def insertion_sort(lst):
    count = 0
    tom = 0
    john = 0
    for todo in range(1, len(lst)):
        tobeinserted = lst[todo]
        i = todo
        count += 1
        while i > 0 and tobeinserted < lst[i-1]:
            lst[i] = lst[i-1] # Make space for the item
            i -= 1
            tom += 1
            if i == 0:
                john += 1
        lst[i] = tobeinserted  # Found the place for this item, plonk it in
        tom += 2
    return "({}, {})".format(tom - (count + john), tom)
