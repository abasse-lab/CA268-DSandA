#
#
def solution():
    return [(11, 1),(5, 11),(12, 4), (13, 11)]